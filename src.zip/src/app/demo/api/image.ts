export interface Image {
    previewImageSrc?:any;
    thumbnailImageSrc?:any;
    alt?:any;
    title?:any;
}
