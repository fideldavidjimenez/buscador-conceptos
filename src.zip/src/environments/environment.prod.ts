export const environment = {
  production: true,
  config_file: 'prod',
  recaptcha: {
    siteKey: '6Lf7UL0cAAAAAIt_m-d24WG4mA1XFPHE8yVckc5S',
  },
};
